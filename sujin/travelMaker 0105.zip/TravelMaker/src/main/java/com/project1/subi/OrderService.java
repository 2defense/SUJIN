package com.project1.subi;

import org.springframework.stereotype.Service;

@Service
public class OrderService {

}
