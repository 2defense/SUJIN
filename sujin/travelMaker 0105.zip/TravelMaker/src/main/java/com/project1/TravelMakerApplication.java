package com.project1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TravelMakerApplication {

	public static void main(String[] args) {
		SpringApplication.run(TravelMakerApplication.class, args);
	}

}
