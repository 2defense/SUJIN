/**
 * 
 */
/*티켓 구매내역 미리띄울게 */
   $('#btnPlan').on('click', function(){
            $('#content').load('/subi/recommendListMain');
        })